package com.deepshikha.expandablelistviewtestjornaldev.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Image {
    @Expose
    @SerializedName("alt")
    private String alt;
    @Expose
    @SerializedName("title")
    private String title;
    @Expose
    @SerializedName("src")
    private String src;
    @Expose
    @SerializedName("date_modified")
    private String dateModified;
    @Expose
    @SerializedName("date_created")
    private String dateCreated;
    @Expose
    @SerializedName("id")
    private int id;

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getDateModified() {
        return dateModified;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
