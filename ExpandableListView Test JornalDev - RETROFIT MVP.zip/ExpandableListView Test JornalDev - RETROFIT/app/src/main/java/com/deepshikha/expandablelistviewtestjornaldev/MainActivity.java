package com.deepshikha.expandablelistviewtestjornaldev;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;

import androidx.appcompat.app.AppCompatActivity;

import com.deepshikha.expandablelistviewtestjornaldev.model.DataModel;
import com.deepshikha.expandablelistviewtestjornaldev.mvp.DataView;
import com.deepshikha.expandablelistviewtestjornaldev.mvp.presenter.DataPresenter;
import com.deepshikha.expandablelistviewtestjornaldev.retrofit.ApiInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements DataView {

    private static final String TAG = "MainActivity >>>";
    ExpandableListView expandableListView;
    CustomExpandableListAdapter expandableListAdapter;

    List<DataModel> categoryList = new ArrayList<>();
    HashMap<DataModel, List<DataModel>> dataModelListHashMap1 = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expandableListView = (ExpandableListView) findViewById(R.id.expandableListView);

//        getResponse();

        DataPresenter dataPresenter = new DataPresenter(this);
        dataPresenter.getDataPresenter();

    }

    @Override
    public void dataReady(List<DataModel> dataModelList) {

        // See your Logcat :)
        for (DataModel dataModel : dataModelList) {
            Log.i("RETROFIT>>>", dataModel.getName() + "\n");
            categoryList = dataModelList;
        }

    }

    @Override
    public void dataReady_hash_map(HashMap<DataModel, List<DataModel>> dataModelListHashMap) {

        dataModelListHashMap1 = dataModelListHashMap;

        setAdapterData();
        expandableListAdapter.notifyDataSetChanged();

    }

    /*private void getResponse() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ApiInterface.JSONURL)
                .addConverterFactory(GsonConverterFactory.create())
//                .addConverterFactory(ScalarsConverterFactory.create())
                .build();

        ApiInterface api = retrofit.create(ApiInterface.class);

        Call<List<DataModel>> call = api.getString1();

        call.enqueue(new Callback<List<DataModel>>() {
            @Override
            public void onResponse(Call<List<DataModel>> call, retrofit2.Response<List<DataModel>> dataList) {
                Log.i("Responsestring", dataList.body().size() + "  ");

                List<DataModel> dataModelList = dataList.body();
                for (int i = 0; i < dataModelList.size(); i++) {
                    Log.e("-Title--", "----->> " + dataModelList.get(i).getName());

                    if (dataModelList.get(i).getParent() == 0) {
                        DataModel model = new DataModel(dataModelList.get(i).getId(), dataModelList.get(i).getName());
                        categoryList.add(model);
                    }

                }

                for (int i = 0; i < categoryList.size(); i++) {
                    List<DataModel> subcategoryList = new ArrayList<>();
                    for (int j = 0; j < dataModelList.size(); j++) {
                        if (dataModelList.get(j).getParent() == categoryList.get(i).getId()) {
                            DataModel model = new DataModel(dataModelList.get(j).getId(), dataModelList.get(j).getName());
                            subcategoryList.add(model);
                        }
                    }
                    dataModelListHashMap.put(categoryList.get(i), subcategoryList);
                }
                setAdapterData();
                expandableListAdapter.notifyDataSetChanged();

            }

            @Override
            public void onFailure(Call<List<DataModel>> call, Throwable t) {
                Log.e(TAG, "onFailure: " + t.getMessage());
            }
        });
    }*/

    public void setAdapterData() {

        expandableListAdapter = new CustomExpandableListAdapter(this, categoryList, dataModelListHashMap1);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                /*Toast.makeText(getApplicationContext(),
                        String.valueOf(categoryList.get(groupPosition)) + " List Expanded.",
                        Toast.LENGTH_SHORT).show();*/
            }
        });

        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
              /*  Toast.makeText(getApplicationContext(),
                        String.valueOf(categoryList.get(groupPosition)) + " List Collapsed.",
                        Toast.LENGTH_SHORT).show();*/
            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                /*Toast.makeText(
                        getApplicationContext(),
                        categoryList.get(groupPosition)
                                + " -> "
                                + dataModelListHashMap.get(
                                dataModelListHashMap.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT
                ).show();*/
                return false;
            }
        });

    }

}