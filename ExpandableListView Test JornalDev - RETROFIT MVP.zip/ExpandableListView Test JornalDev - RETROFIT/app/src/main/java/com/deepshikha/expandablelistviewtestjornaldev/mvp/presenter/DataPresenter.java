package com.deepshikha.expandablelistviewtestjornaldev.mvp.presenter;

import android.util.Log;

import com.deepshikha.expandablelistviewtestjornaldev.MainActivity;
import com.deepshikha.expandablelistviewtestjornaldev.model.DataModel;
import com.deepshikha.expandablelistviewtestjornaldev.mvp.DataView;
import com.deepshikha.expandablelistviewtestjornaldev.mvp.service.DataService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DataPresenter {

    private DataView dataView;
    private DataService dataService;

    public DataPresenter(DataView view) {
        this.dataView = view;

        if (this.dataService == null) {
            this.dataService = new DataService();
        }
    }

    public void getDataPresenter() {
        dataService
                .getAPI()
                .getString1()
                .enqueue(new Callback<List<DataModel>>() {
                    @Override
                    public void onResponse(Call<List<DataModel>> call, Response<List<DataModel>> dataList) {
                        Log.i("Responsestring", dataList.body().size() + "  ");

                        List<DataModel> dataModelList = dataList.body();

                        List<DataModel> categoryList = new ArrayList<>();
                        HashMap<DataModel, List<DataModel>> dataModelListHashMap = new HashMap<>();

                        for (int i = 0; i < dataModelList.size(); i++) {
                            Log.e("-Title--", "----->> " + dataModelList.get(i).getName());

                            if (dataModelList.get(i).getParent() == 0) {
                                DataModel model = new DataModel(dataModelList.get(i).getId(), dataModelList.get(i).getName());
                                categoryList.add(model);
                            }

                        }

                        for (int i = 0; i < categoryList.size(); i++) {
                            List<DataModel> subcategoryList = new ArrayList<>();
                            for (int j = 0; j < dataModelList.size(); j++) {
                                if (dataModelList.get(j).getParent() == categoryList.get(i).getId()) {
                                    DataModel model = new DataModel(dataModelList.get(j).getId(), dataModelList.get(j).getName());
                                    subcategoryList.add(model);
                                }
                            }
                            dataModelListHashMap.put(categoryList.get(i), subcategoryList);
                        }

                        dataView.dataReady(categoryList);
                        dataView.dataReady_hash_map(dataModelListHashMap);

                    }

                    @Override
                    public void onFailure(Call<List<DataModel>> call, Throwable t) {

                    }

                   /* @Override
                    public void onResponse(Call<Data> call, Response<Data> response) {
                        Data data = response.body();

                        if (data != null && data.getRestResponse() != null) {
                            List<Country> result = data.getRestResponse().getResult();
                            dataView.dataReady(result);
                        }
                    }

                    @Override
                    public void onFailure(Call<Data> call, Throwable t) {
                        try {
                            throw new InterruptedException("Something went wrong!");
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }*/
                });
    }
}