package com.deepshikha.expandablelistviewtestjornaldev.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DataModel {


    @Expose
    @SerializedName("image")
    private Image image;
    @Expose
    @SerializedName("parent")
    private int parent;

    public DataModel() {

    }

    public DataModel(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Expose
    @SerializedName("name")
    private String name;
    @Expose
    @SerializedName("id")
    private int id;


    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }


    public int getParent() {
        return parent;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
