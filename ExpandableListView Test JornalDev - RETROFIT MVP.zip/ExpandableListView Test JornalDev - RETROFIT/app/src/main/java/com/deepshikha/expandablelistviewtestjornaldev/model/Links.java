package com.deepshikha.expandablelistviewtestjornaldev.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Links {
    @Expose
    @SerializedName("collection")
    private List<Collection> collection;
    @Expose
    @SerializedName("self")
    private List<Self> self;

    public List<Collection> getCollection() {
        return collection;
    }

    public void setCollection(List<Collection> collection) {
        this.collection = collection;
    }

    public List<Self> getSelf() {
        return self;
    }

    public void setSelf(List<Self> self) {
        this.self = self;
    }
}
