package com.deepshikha.expandablelistviewtestjornaldev.retrofit;

import com.deepshikha.expandablelistviewtestjornaldev.model.DataModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {

//    String JSONURL = "http://demonuts.com/Demonuts/JsonTest/Tennis/";

//    @GET("json_parsing.php")
//    Call<String> getString();

    String JSONURL = "https://www.tecocraft.com";

    @GET("/eatenglish/test_category.json")
    Call<List<DataModel>> getString1();

}
