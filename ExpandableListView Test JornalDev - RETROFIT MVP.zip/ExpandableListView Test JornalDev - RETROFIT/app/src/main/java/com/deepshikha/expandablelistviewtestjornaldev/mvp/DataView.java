package com.deepshikha.expandablelistviewtestjornaldev.mvp;

import com.deepshikha.expandablelistviewtestjornaldev.model.DataModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public interface DataView {

    void dataReady(List<DataModel> dataModelList);

    void dataReady_hash_map(HashMap<DataModel, List<DataModel>> dataModelListHashMap);
}
