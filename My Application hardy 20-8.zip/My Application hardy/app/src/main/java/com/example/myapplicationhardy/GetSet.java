package com.example.myapplicationhardy;

public class GetSet {

    public int idz;
    public String name;
    public String slug;
    public String parent;
    public String description;
    public String display;
    public String menu_order;
    public String count;

    public int id2;
    public String date_created;
    public String date_modified;
    public String src;
    public String title;
    public String alt;

    public String self_href;
    public String collection_self;

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public String getMenu_order() {
        return menu_order;
    }

    public void setMenu_order(String menu_order) {
        this.menu_order = menu_order;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    public String getDate_modified() {
        return date_modified;
    }

    public void setDate_modified(String date_modified) {
        this.date_modified = date_modified;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdz() {
        return idz;
    }

    public void setIdz(int idz) {
        this.idz = idz;
    }

    public int getId2() {
        return id2;
    }

    public void setId2(int id2) {
        this.id2 = id2;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public String getSelf_href() {
        return self_href;
    }

    public void setSelf_href(String self_href) {
        this.self_href = self_href;
    }

    public String getCollection_self() {
        return collection_self;
    }

    public void setCollection_self(String collection_self) {
        this.collection_self = collection_self;
    }

    public GetSet() {

    }
}