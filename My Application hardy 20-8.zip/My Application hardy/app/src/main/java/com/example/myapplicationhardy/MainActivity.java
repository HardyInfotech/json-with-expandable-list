package com.example.myapplicationhardy;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    String url = "https://www.tecocraft.com/eatenglish/test_category.json";

    RecyclerView mList;

    LinearLayoutManager linearLayoutManager;
    DividerItemDecoration dividerItemDecoration;
    private List<GetSet> getSetList;
    private RecyclerView.Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mList = findViewById(R.id.main_list);

        getSetList = new ArrayList<>();
        adapter = new MainAdapter(getApplicationContext(), getSetList);

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(mList.getContext(), linearLayoutManager.getOrientation());

        mList.setHasFixedSize(true);
        mList.setLayoutManager(linearLayoutManager);
        mList.addItemDecoration(dividerItemDecoration);
        mList.setAdapter(adapter);

        getData();
    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject1 = response.getJSONObject(i);

                        GetSet getSet = new GetSet();
                        getSet.setIdz(jsonObject1.getInt("id"));
                        getSet.setName(jsonObject1.getString("name"));
                        getSet.setSlug(jsonObject1.getString("slug"));
                        getSet.setParent(jsonObject1.getString("parent"));
                        getSet.setDescription(jsonObject1.getString("description"));
                        getSet.setDisplay(jsonObject1.getString("display"));
                        getSet.setMenu_order(jsonObject1.getString("menu_order"));
                        getSet.setCount(jsonObject1.getString("count"));

                        //============
                        JSONObject jsonObject2 = jsonObject1.getJSONObject("image");
                        getSet.setId2(jsonObject2.getInt("id"));
                        getSet.setDate_created(jsonObject2.getString("date_created"));
                        getSet.setDate_modified(jsonObject2.getString("date_modified"));
                        getSet.setSrc(jsonObject2.getString("src"));
                        getSet.setTitle(jsonObject2.getString("title"));
                        getSet.setAlt(jsonObject2.getString("alt"));
                        //============

                        //============
                        JSONObject jsonObject3 = jsonObject1.getJSONObject("_links");
//                        JSONObject jsonObject4 = jsonObject3.getJSONObject("self");
//                        JSONObject jsonObject5 = jsonObject4.getJSONObject("0");
//                        getSet.setSelf_href(jsonObject5.getString("href"));

                        JSONArray jsonObject4 = jsonObject3.getJSONArray("self");
                        for (int i2 = 0; i2 < jsonObject4.length(); i2++) {
                            JSONObject elem = jsonObject4.getJSONObject(i2);
                            if (elem != null) {
                                getSet.setSelf_href(elem.getString("href"));
                            }
                        }

                        JSONArray jsonObject5 = jsonObject3.getJSONArray("collection");
                        for (int i2 = 0; i2 < jsonObject5.length(); i2++) {
                            JSONObject elem = jsonObject5.getJSONObject(i2);
                            if (elem != null) {
                                getSet.setCollection_self(elem.getString("href"));
                            }
                        }
                        //============

                        getSetList.add(getSet);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        progressDialog.dismiss();
                    }
                }
                adapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
}