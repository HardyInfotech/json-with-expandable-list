package com.example.myapplicationhardy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Created by ankit on 27/10/17.
 */

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {

    private Context context;
    private List<GetSet> list;

    public MainAdapter(Context context, List<GetSet> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.single_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        GetSet getSet = list.get(position);

        holder.tv_id.setText("id = " + getSet.getIdz());
        holder.tv_name.setText("name = " + getSet.getName());
        holder.tv_slug.setText("slug = " + getSet.getSlug());
        holder.tv_parent.setText("parent = " + getSet.getParent());
        holder.tv_description.setText("description = " + getSet.getDescription());
        holder.tv_display.setText("display = " + getSet.getDisplay());
        holder.tv_menu_order.setText("menu_order = " + getSet.getMenu_order());
        holder.tv_count.setText("count = " + getSet.getCount());

        holder.tv_id2.setText("id2 = " + getSet.getId2());
        holder.tv_date_created.setText("date_created = " + getSet.getDate_created());
        holder.tv_date_modified.setText("date_modified = " + getSet.getDate_modified());
        holder.tv_src.setText("src = " + getSet.getSrc());
        holder.tv_title.setText("title = " + getSet.getTitle());
        holder.tv_alt.setText("alt = " + getSet.getAlt());

        holder.tv_self_href.setText("self_href = " + getSet.getSelf_href());
        holder.tv_collection_self.setText("collection_self = " + getSet.getCollection_self());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_id, tv_name, tv_slug, tv_parent, tv_description, tv_display,
                tv_menu_order, tv_count;

        public TextView tv_id2, tv_date_created, tv_date_modified, tv_src, tv_title, tv_alt;

        public TextView tv_self_href, tv_collection_self;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_id = itemView.findViewById(R.id.tv_id);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_slug = itemView.findViewById(R.id.tv_slug);
            tv_parent = itemView.findViewById(R.id.tv_parent);
            tv_description = itemView.findViewById(R.id.tv_description);
            tv_display = itemView.findViewById(R.id.tv_display);
            tv_menu_order = itemView.findViewById(R.id.tv_menu_order);
            tv_count = itemView.findViewById(R.id.tv_count);

            tv_id2 = itemView.findViewById(R.id.tv_id2);
            tv_date_created = itemView.findViewById(R.id.tv_date_created);
            tv_date_modified = itemView.findViewById(R.id.tv_date_modified);
            tv_src = itemView.findViewById(R.id.tv_src);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_alt = itemView.findViewById(R.id.tv_alt);

            tv_self_href = itemView.findViewById(R.id.tv_self_href);
            tv_collection_self = itemView.findViewById(R.id.tv_collection_self);

        }
    }

}