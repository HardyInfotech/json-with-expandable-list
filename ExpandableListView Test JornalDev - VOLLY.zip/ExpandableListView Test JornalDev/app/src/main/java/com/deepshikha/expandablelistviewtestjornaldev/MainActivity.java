package com.deepshikha.expandablelistviewtestjornaldev;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ExpandableListView expandableListView;
    CustomExpandableListAdapter expandableListAdapter;

    List<DataModel> categoryList = new ArrayList<>();
    HashMap<DataModel, List<DataModel>> dataModelListHashMap = new HashMap<>();
    String url = "https://www.tecocraft.com/eatenglish/test_category.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expandableListView = (ExpandableListView) findViewById(R.id.expandableListView);

        getData();

    }

    private void getData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject1 = response.getJSONObject(i);
                        if (jsonObject1.optInt("parent") == 0) {
                            DataModel model = new DataModel(jsonObject1.optInt("id"), jsonObject1.optString("name"));
                            categoryList.add(model);
                        }

                    } catch (JSONException e) {
                        Log.e("Error:", e.getMessage());
                    }
                }

                for (int i = 0; i < categoryList.size(); i++) {
                    List<DataModel> subcategoryList = new ArrayList<>();
                    for (int j = 0; j < response.length(); j++) {
//                        Log.e("-->>>>>> ",categoryList.get(i).getId()+" ");
                        try {
                            JSONObject jsonObject1 = response.getJSONObject(j);
//                            Log.e("-->>>>>> ",categoryList.get(i).getId()+" ==  "+jsonObject1.optInt("parent")+" ");
//                            Log.d("-->>>>>> ",(jsonObject1.optInt("parent") == categoryList.get(i).getId())+" <-----------");
                            if (jsonObject1.optInt("parent") == categoryList.get(i).getId()) {
                                DataModel model = new DataModel(jsonObject1.optInt("id"), jsonObject1.optString("name"));
                                subcategoryList.add(model);
                            }
                        } catch (JSONException e) {
                            Log.e("Error:", e.getMessage());
                        }
                    }
                    dataModelListHashMap.put(categoryList.get(i), subcategoryList);
                }
                setAdapterData();
                expandableListAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
                progressDialog.dismiss();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    public void setAdapterData() {

        expandableListAdapter = new CustomExpandableListAdapter(this, categoryList, dataModelListHashMap);
        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        String.valueOf(categoryList.get(groupPosition)) + " List Expanded.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        expandableListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        String.valueOf(categoryList.get(groupPosition)) + " List Collapsed.",
                        Toast.LENGTH_SHORT).show();

            }
        });

        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        categoryList.get(groupPosition)
                                + " -> "
                                + dataModelListHashMap.get(
                                dataModelListHashMap.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT
                ).show();
                return false;
            }
        });

    }

}